import React from 'react';

import Header from './Header';


const Home = () =>{
  return (
    <div>
      <Header />
    </div>
  );
}

export default Home;