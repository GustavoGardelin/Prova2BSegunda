import React from 'react';
import './Header.css';
import Noticias from "./Noticias";


function Header() {
    return (
        <header className="header">
            {/* Seção principal */}
            <section className="intro">
                <img 
                    src="https://img.freepik.com/vetores-premium/cartoon-de-menino-com-design-de-laptop-comunicacao-de-tecnologia-digital-midias-sociais-internet-e-tema-da-web-ilustracao-vetorial_1142-154370.jpg" 
                    alt="Janae Cobos" 
                    className="intro-image"
                />
                <div className="intro-text">
                    <h2>Olá</h2>
                    <p>Sou o Gustavo, empreendedor digital e acadêmico de Análise e Desenvolvimento de Sistemas.</p>
                </div>
                {/* Uso correto do componente Noticias */}
                <Noticias />
            </section>

            {/* Marcas */}
            <footer className="brands-section">
                <h3>Alguns dos marketplaces com que trabalho:</h3>
                <div className="brands">
                <img src="https://seeklogo.com/images/M/mercado-livre-logo-D1DC52B13E-seeklogo.com.png" alt="Mercado Livre" />
        <img src="https://img.icons8.com/color/512/shopee.png" alt="Shop" />
        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAMAAACahl6sAAAAzFBMVEUPiP////8Oif/9/v0Oif0SiPf4/v7o+P2Nx/8tl/8aiO8vku/h8P8ekP+Ox/S73/dDnvBjsPLw9/95uu/D4f+i0fPb8ftGU/sOpPpptf9gMvnN6flWqfB3vP9Lpv8zav0kgf6s1f8DvvF5DP0N0aS2CN4U6VEP3IHzE7nUDcyYBPANrMcHysg8nv/6zzT9Ugn8HZr7rCf8jhqZOtP7cBD9KHdgW+Rarv/8M1dmdqT8PDphmar8RSCnX2xnZMSmS5+ohmiprHauyoE3qbLEiJHYAAANBUlEQVR4nOWdi7+axhLHF9gFBAV8YGJQE9u0aZue9vY2vSdNe/tI////6c5jQXyyKirr/flJe9yDMF9mdmYXOYtwrqJ+sQoXs+VTrzcQpEGvt1zOFuFqMrrOEUXbO+yvwtmTtn6/Bk/PYfs4rYJMwufeMYS6ekDT5rFbAynC5VE/7PXNMizaOn47IJOFsSd2PDNrxzEtgEwWJ7viCiyXgozCCyk0y6J/V5DJsg0K1nJ1L5CWnLFWb3WBW84GaR2DUGZno5wJchUM0rkoZ4FcD+N8lDNArosB6oU3AVmdXfuM5fZWVwfpt5hwj+n51Pg6EeTaUVXTifF1Esjk+lFVU+8kp5wCsrglBuoUp5iD9J9uzXGSU4xBbtg7ahoYO8UQZHTzsCq1MJwUm4HcI6xKGYaXEcjkLmFVkRhNu0xAwntioEw6igHI3TmEa0DSCDKa3RsDNbsYZHTHbl7XU1PyagC5Z7ra1FND8joO0r/p4Oq4GtLwUZAucTSRHAPpFkcDyRGQrvTztY71+CMgneM4SnIYpBP1Y1uH68lBkPvX8706WOMPgXSU4zDJAZDJve09rANj4f0gXUu8dQ32J+G9IKMOcxxKXXtB7javNdPCFKSzHb3Uvg6/B6R/14mtifZ1kz0gne4grCcTkM4HFmq3m+yA9O9to5l2qskOiAWBheo1gVgRWKjtzLUFYklgid3MtQXyfG/7zLU8BrK6t3WnaHUExJKezuqNDoJY09NZ4SGQLg/e92kwOgDSyVn6MYX7QexJvaXqLqmBWOeQDZcIix2y4RJhs0PqLqlAbEtZrLVLKhCrivpa4Q6IlQ4Bl2yDWOqQ9QyrBLnRbVjta7kJYmPu1RptgHT8ktwxhRsglnZ11KAO0uGL782a1ECsrOqlFjUQiyOrjC1hfWTp2BLWR5aOLWF9ZOmrjghS3NuSS1VoEMsunuwq1CDWjrNKLTVI57+hatKAQSxPvqgJgVjfRaiTCKuuwB/SM4FYXkVQPQQZNW7mCqFQ0mUJIddvpauibDicx0rKdbN0JbVm8JY/XLbG8+Ewi6BZt8qNXbtSv9c7179sNLEPIAZ9Xao8CIJEuXr3cj4NgiKSaJmK88D3PN9PM5UV0BxLVDyeUut0qOI0CKZDalXD1Pd9zw+SWCVT3KXM4H9BXpHw+0STKPgo7rHRwhWANPd1V2RglOcPpeCDxVN46w3ZtAB+xDGC5yc5No+lFCqblq1eOsbWVAopo9Qvt51m+Lkgkgn+1o8qkMRzsF0wFbzx/aFqNDEEkOa+7sq558Pup5E+T2AwvE0wrMY+/ki2wSHRBwCi5vgTtepmAJFuVFAbNdMO1yBxFVv0PtAeyfDzcMYaTZwBSPOti64cenS4Me1eZAEa4eXgkCwgg8g0LdiIPebVGh0AUYnn1zcFoF0QpUEUH4l2YgDyBCDNdR3OOx8/wOOJqMDdO16qpMJYATuKJMmnaKbnAC0bAx7Mk6TwmSiVLsUnbAytKccjeQQ9tAYRCTpYhxZ8BN03bO7sA0c0Jy0I7oRDwksg/uVQBwiAsG3BEJBUlJcgUUAGJ5HAKAvoJMDG1IO8NJawNfYh8ojYApEMojt/Rv428IjoC5OkBTYghoMu0XGDo38lxxxx0BkxnaboKH8s5mQxZCJolbgNeSSiz01hD5hjM78G4h0BMQstUQiTa6UaBGInVyrRse9MIzTdgRwgMH9BSvAJxB2vwx4rx5RBYkwLfoIYmO3Sdj2yEiYjLUkGUwrOIG2C7T4FMvYWOvVYI8FXAYFwBp2iLQJDMaXQAkwEycgh0Jrs9wi+p2x2okdCYXCN0ZUFnUzMqWlKFQVp/BijxcGTzGUymhKIos5QKEGNFJcIMsSzG8R6WzmuQLbrCKdlwSAYlyYgC2Fw4UGqKZ3MtEycSaxBENAry/KmR/ikUvVgkLlHn+HzzolwP4hDdcTVdcQQZCYMpoeYhjCOMypzeFojAslUyueejZPZRh/JGEQSNIBkFFrDchBV9ZHNOsIhp8Ekpw0TkKURSEwgEccM1kV0kePNdTXLMA6g/+actXRSLiKyJUqp6qRSBVThOeIU7ZILIvaReVXZyVPesD6EMAF5EgaDeEg4HCsx2QKjRYo1OACdZa+IFfgDRivoEW/sUg7wvWIeRVFWlAVR15EkcqGOxOQQBOFaW8RRpGDzCHMCHiMWsNXQNw6tngmIolM8jVwJtvrBHAaFBAKlb0qpLEjmcxjXOlTwYYiiRzT+tJj6VWWXZBaMksfzecL1EEOL+7OH28IrhailzQrYKg8okg1BDK48YMJxoCtA+Z7DFANHtwWDaJPRPp8GUuQRAR3A5zGV75UgSqgqWXBfY4+owqvJn+P4pvyslgmI2QUUcj+YQgUAB6YSbXIS6hf+2gpCGcNmsR6OUS3XWYtGmF41lNSVHeY2NO4i46EjzssRJzX4xh4xEqdEBsFhh6tPLg5CkMTR1uVUMcaYqqKEfQFDROoOBCJpDsKEAY3BsF6UMxrex5zINJefp+2CDAMf5xllYpHUsX2ohJCBFE0FMaqHCk65H2S8RTZOiyJNMqXIO6mLmY1nk4CRZyqHPaQRTqOzfIoHQAUxuHzOY2qvGMOQE/fYFoirYpBac7jcQvMsqDLzJM/HOA+nVqlLN82+JeVuAMm5qqh4nOTJECf4ivbg0pAlirWwAQfH4zxP5lG5UUscOqIqh7guD62kvsyAPyveBFzEYwtqwC1URNHhD91yxCJ5d/Tibct2KOd0HLHeytW7bQ9E1kAkH1CPbiWPfV2yC3+FzcN8GJFtMc1SYPSu/eS65XkRbCdDCOLE/ke/4kbet2sIYpJ+9ahpQ3K7QV9iIRsgnPwgzZM8DbgPj9XmZ+m/YnsPeqhDxtNJKrc2wTAoiPsOd1gIkqxzssPDlb02G6vZRqPKfuJRIaA4kemS4fO08NogBn//eSoI5mtdGhwuJerqIEaj31MPS1k2Dfgy1xRKRhXu1wQxmFiddWAVZXO8+BupyxgMQWZGU93TRZnHpby5m96uAbIwufhw1pHJftkGhRFIaHI5yN2PcsxErgP6R1OWw9s127gSBl+y87cUx4UjK9xOHL1yvlWiuWTLo1LKqLJPROO9c6772+fPf5P++vsvrf/W9Geln//8eUOv8FXXi1cvWK9Jb1DSfSlfkr54+QXo/fvv4fX2/VvUu7fv3r0zGTWODC5iu59/QP0E+jfqw4cPP374EfX7759AHz99/PgL6F+kb1Dfor769ivWd6AvWa++JJ6KBUEYAxm++B7FBKivWe+bQQYmXyvUQH7SICUHkXxEVSTffFOhaJLvWJpEu0ajAEj8pgZSopAn3n3NKP+Yfa3QXEgI5KcfahwVyCcNQhy/VA5hl5QcX215hAOsjK2XbsXBLqk8ojm+fttooXg2+OrN3fZI5ZKaR7YcUudgj3z53TqyarFFveRl5RLyyNvvt0gMQgu/emvMv278W02/buqPX/9Y6z91vaB/L2p6rfv46zeaAIWTEvdlTe/xVdM/76Pm7xAnANKYtvQUSuj5EM+meCKn60RZKnimyCWhbHLr6ZU9TNN3oQstTar0GaNkyx9y6cB4lQ5fjSAjoxsGyoqmbSiLFx8cf+8KPRphQ5mWvgQU9E9ulLV1zax+5lb+iJ4frqupwbyqd6tbOA6XZ1cIg7rdpOfHuqnmYW5zepgbzx7nVkDrO0l5c+bD3C5r+61n1Q3MNv8ZDGr2eDf5252Ae7W/H7E6tmaP+KdJNseWXupFg1hcExcbIAb30XVV/Q0Qe8dbW3/iam93X22B2Nrdq1WdKhBLu/tqB2RkpUvWK+euF6+w0iXrRVrXIFa6pL8HxEaX1FbNrYFY6JL+XhD7XFJfxrgOYptLNhb7fsiFwjq+PO62NpdqfNDF9GwaBD87x0C6v0RupeMLTtrT3xuWALXmqmPjoqy2zLB21mDeXbjYimtcu6ti71lKuoMPh9jWTmA99uLe3c9chsutd76bGC+A38FnwdTVM38kQae7yYEn9Tz4Yzs63OFPfJBKZ0lOfrRNRxfdOuNhQ51MXXseDtEM0kGSMx/I1bmVc899RFrXSM5/aF23SC55jODjPNixOz3+0kdtOh2pJ7PG5x1b8Thakwfr/j89IPjWD5jf1qC1RzbfNw03pauTQB7msebOwzxo3rlPeBmG1Wkgd8heey+XtAByY6eYPWD+LJBbOsW8d5wF4vRvtGDo0rx3nAfiOKsbxFdvdbJZp4NAfF0ZZRAa1o5LQZz+NUfEZ2GcCXJFlDMxzgZBlCsE2NkYF4AAStvd/gKMi0BAqxZvMFieVP9aBgG3LFpxy0XOaAUENLm0twwWlzmjLRDnIpZeGxROWyCgIlyePGMZLMOireO3BoKahM/Gnuk9h+24QqtVENQIaJ6O+mbwNAtXp44JG9U6CGs0WYWL2XLZ62mmQa/3tJwtwlXROgLrf5nvH6AfD67FAAAAAElFTkSuQmCC" alt="Magazine Luiza" />
                </div>
            </footer>
        </header>
    );
}

export default Header;
